import React from 'react'
import Board from "./Components/Board"
import "./index.css"
const App = () => {
  return (
    <div>
      <Board/>
    </div>
  )
}

export default App